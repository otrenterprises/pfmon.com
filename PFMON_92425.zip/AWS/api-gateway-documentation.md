# PFMON API Gateway Documentation

## 🚀 API Gateway Overview

**API Name**: `pfmon-test-api`  
**API ID**: `g1zeanpn1a`  
**Region**: `us-east-1`  
**Endpoint**: `https://g1zeanpn1a.execute-api.us-east-1.amazonaws.com/prod`  
**Stage**: `prod`  
**Created**: September 3, 2025

## 🔐 Authentication & Authorization

**Authentication Type**: Cognito User Pools  
**Authorizer**: `pfmon-cognito-authorizer` (ID: `btzhjb`)  
**User Pool**: `us-east-1_Jj0h3DRZz`  
**User Pool ARN**: `arn:aws:cognito-idp:us-east-1:427687728291:userpool/us-east-1_Jj0h3DRZz`

### Authorization Header Format
```
Authorization: Bearer <JWT_TOKEN>
```

All endpoints (except OPTIONS) require valid Cognito JWT tokens. Unauthorized requests return `401 Unauthorized`.

## 📋 API Endpoints

### Base URL
```
https://g1zeanpn1a.execute-api.us-east-1.amazonaws.com/prod
```

### User Profile Endpoints

#### Get User Profile
- **Method**: `GET`
- **Path**: `/api/users/{userId}/profile`
- **Lambda**: `pfmon-test-user-profiles-api`
- **Authorization**: Required (Cognito)
- **Description**: Retrieve user profile information

#### Create/Update User Profile
- **Method**: `POST`
- **Path**: `/api/users/{userId}/profile`
- **Lambda**: `pfmon-test-user-profiles-api`
- **Authorization**: Required (Cognito)
- **Description**: Create or update user profile

#### CORS Preflight (Profile)
- **Method**: `OPTIONS`
- **Path**: `/api/users/{userId}/profile`
- **Authorization**: None
- **Description**: CORS preflight requests

### Journal Endpoints

#### Get Journal Entries
- **Method**: `GET`
- **Path**: `/api/users/{userId}/journal`
- **Lambda**: `pfmon-test-journal-api`
- **Authorization**: Required (Cognito)
- **Description**: Retrieve user's journal entries

#### Create Journal Entry
- **Method**: `POST`
- **Path**: `/api/users/{userId}/journal`
- **Lambda**: `pfmon-test-journal-api`
- **Authorization**: Required (Cognito)
- **Description**: Create new journal entry

#### Update Journal Entry
- **Method**: `PUT`
- **Path**: `/api/users/{userId}/journal`
- **Lambda**: `pfmon-test-journal-api`
- **Authorization**: Required (Cognito)
- **Description**: Update existing journal entry

#### Delete Journal Entry
- **Method**: `DELETE`
- **Path**: `/api/users/{userId}/journal`
- **Lambda**: `pfmon-test-journal-api`
- **Authorization**: Required (Cognito)
- **Description**: Delete journal entry

#### CORS Preflight (Journal)
- **Method**: `OPTIONS`
- **Path**: `/api/users/{userId}/journal`
- **Authorization**: None
- **Description**: CORS preflight requests

## 🔗 Lambda Function Integrations

### Integration Configuration
- **Integration Type**: `AWS_PROXY`
- **Integration Method**: `POST` (for all HTTP methods)
- **Timeout**: 29,000ms (29 seconds)

### Connected Lambda Functions

#### User Profiles API
- **Function Name**: `pfmon-test-user-profiles-api`
- **Function ARN**: `arn:aws:lambda:us-east-1:427687728291:function:pfmon-test-user-profiles-api`
- **Handler**: `api-user-profiles.handler`
- **Runtime**: Node.js 20.x
- **Layer**: `pfmon-jwt-layer:1`

#### Journal API
- **Function Name**: `pfmon-test-journal-api`
- **Function ARN**: `arn:aws:lambda:us-east-1:427687728291:function:pfmon-test-journal-api`
- **Handler**: `api-journal-entries.handler`
- **Runtime**: Node.js 20.x
- **Layer**: `pfmon-jwt-layer:1`

## 🛡️ IAM Permissions

### API Gateway → Lambda Permissions

#### User Profiles Lambda Permission
```json
{
  "Sid": "apigateway-invoke",
  "Effect": "Allow",
  "Principal": {
    "Service": "apigateway.amazonaws.com"
  },
  "Action": "lambda:InvokeFunction",
  "Resource": "arn:aws:lambda:us-east-1:427687728291:function:pfmon-test-user-profiles-api",
  "Condition": {
    "ArnLike": {
      "AWS:SourceArn": "arn:aws:execute-api:us-east-1:427687728291:g1zeanpn1a/*/*"
    }
  }
}
```

#### Journal Lambda Permission
```json
{
  "Sid": "apigateway-invoke",
  "Effect": "Allow",
  "Principal": {
    "Service": "apigateway.amazonaws.com"
  },
  "Action": "lambda:InvokeFunction",
  "Resource": "arn:aws:lambda:us-east-1:427687728291:function:pfmon-test-journal-api",
  "Condition": {
    "ArnLike": {
      "AWS:SourceArn": "arn:aws:execute-api:us-east-1:427687728291:g1zeanpn1a/*/*"
    }
  }
}
```

## 🌐 CORS Configuration

### CORS Methods Enabled
- Profile endpoints: `GET, POST, OPTIONS`
- Journal endpoints: `GET, POST, PUT, DELETE, OPTIONS`

### CORS Headers (Partial Setup)
- **Access-Control-Allow-Origin**: `*`
- **Access-Control-Allow-Methods**: Method-specific
- **Access-Control-Allow-Headers**: `Content-Type, X-Amz-Date, Authorization, X-Api-Key, X-Amz-Security-Token`

*Note: CORS configuration is partially complete. Full CORS headers may need additional setup for production use.*

## 📊 Resource Structure

```
/ (Root)
└── api
    └── users
        └── {userId}
            ├── profile (GET, POST, OPTIONS)
            └── journal (GET, POST, PUT, DELETE, OPTIONS)
```

### Resource IDs
- **Root**: `bienfhdl9d`
- **api**: `tllru9`
- **users**: `7m72uv`
- **{userId}**: `lyj410`
- **profile**: `i32jkv`
- **journal**: `h7q54y`

## 🧪 Testing

### Test Authentication (Expected: 401)
```bash
curl -X GET "https://g1zeanpn1a.execute-api.us-east-1.amazonaws.com/prod/api/users/test123/profile" \
     -H "Authorization: Bearer invalid-token"
```

### Test with Valid Token (After React App Integration)
```bash
curl -X GET "https://g1zeanpn1a.execute-api.us-east-1.amazonaws.com/prod/api/users/{userId}/profile" \
     -H "Authorization: Bearer {valid-jwt-token}"
```

## 🔧 Management Commands

### Get API Information
```bash
aws apigateway get-rest-api --rest-api-id g1zeanpn1a --region us-east-1
```

### Get Resources
```bash
aws apigateway get-resources --rest-api-id g1zeanpn1a --region us-east-1
```

### Redeploy API (After Changes)
```bash
aws apigateway create-deployment --rest-api-id g1zeanpn1a --stage-name prod --region us-east-1
```

### Delete API (If Needed)
```bash
aws apigateway delete-rest-api --rest-api-id g1zeanpn1a --region us-east-1
```

## 📝 Integration Notes

### React App Integration
1. Replace mock API calls with: `https://g1zeanpn1a.execute-api.us-east-1.amazonaws.com/prod`
2. Include Cognito JWT token in Authorization header
3. Handle 401 responses (token expired/invalid)
4. Update API endpoints to match the structure above

### Lambda Function Environment Variables
Both Lambda functions have access to:
- `USER_PROFILES_TABLE_NAME`: `pfmon-test-UserProfiles`
- `JOURNAL_ENTRIES_TABLE_NAME`: `pfmon-test-JournalEntries`
- `COGNITO_USER_POOL_ID`: `us-east-1_Jj0h3DRZz`
- `REGION`: `us-east-1`

### DynamoDB Tables Connected
- **UserProfiles**: `pfmon-test-UserProfiles`
- **JournalEntries**: `pfmon-test-JournalEntries`
- **UserCredentials**: `pfmon-test-UserCredentials`
- **AccountData**: `pfmon-test-AccountData`

---

**Status**: ✅ API Gateway deployed and functional  
**Last Updated**: September 3, 2025  
**Next Step**: Update React app to use these endpoints