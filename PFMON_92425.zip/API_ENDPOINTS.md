# 🚀 PFMON API Endpoints Documentation

## 📅 Last Updated: September 4, 2025

---

## 🌐 **Base URL**
```
https://g1zeanpn1a.execute-api.us-east-1.amazonaws.com/prod
```

## 🔐 **Authentication**
All endpoints (except OPTIONS) require JWT token authentication:
```
Authorization: Bearer {JWT_TOKEN}
```

---

## 📋 **Current API Endpoints**

### **👤 User Profile Endpoints**

#### GET `/api/users/{userId}/profile`
**Description**: Retrieve user profile information  
**Method**: `GET`  
**Authentication**: Required (Cognito JWT)  
**Lambda Function**: `pfmon-test-user-profiles-api`

**Request:**
```bash
GET /api/users/1448a458-6061-70ce-fb89-543829daaa9d/profile
Authorization: Bearer eyJhbGciOiJSUzI1NiIs...
```

**Response (200 OK):**
```json
{
  "statusCode": 200,
  "data": {
    "userId": "1448a458-6061-70ce-fb89-543829daaa9d",
    "email": "user@example.com",
    "preferences": {
      "theme": "dark",
      "timezone": "America/New_York",
      "notifications": true
    },
    "createdAt": "2025-09-03T15:30:00.000Z",
    "updatedAt": "2025-09-04T03:15:00.000Z"
  }
}
```

**Response (404 Not Found):**
```json
{
  "statusCode": 404,
  "message": "User profile not found"
}
```

---

#### PUT `/api/users/{userId}/profile`
**Description**: Create or update user profile  
**Method**: `PUT`  
**Authentication**: Required (Cognito JWT)  
**Lambda Function**: `pfmon-test-user-profiles-api`

**Request:**
```bash
PUT /api/users/1448a458-6061-70ce-fb89-543829daaa9d/profile
Authorization: Bearer eyJhbGciOiJSUzI1NiIs...
Content-Type: application/json

{
  "email": "user@example.com",
  "preferences": {
    "theme": "light",
    "timezone": "America/Chicago",
    "notifications": false
  }
}
```

**Response (200 OK):**
```json
{
  "statusCode": 200,
  "message": "Profile updated successfully",
  "data": {
    "userId": "1448a458-6061-70ce-fb89-543829daaa9d",
    "email": "user@example.com",
    "preferences": {
      "theme": "light",
      "timezone": "America/Chicago", 
      "notifications": false
    },
    "updatedAt": "2025-09-04T03:20:00.000Z"
  }
}
```

---

#### OPTIONS `/api/users/{userId}/profile`
**Description**: CORS preflight request  
**Method**: `OPTIONS`  
**Authentication**: None  
**Integration**: Mock (API Gateway)

**Response Headers:**
```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS
Access-Control-Allow-Headers: Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token
```

---

### **📓 Journal Entry Endpoints**

#### GET `/api/users/{userId}/journal`
**Description**: Retrieve user's journal entries  
**Method**: `GET`  
**Authentication**: Required (Cognito JWT)  
**Lambda Function**: `pfmon-test-journal-api`

**Query Parameters:**
- `type` (optional): Filter by entry type (TRADE, LESSON, MISTAKE)
- `limit` (optional): Number of entries to return (default: 50)
- `lastEvaluatedKey` (optional): Pagination key for next page

**Request:**
```bash
GET /api/users/1448a458-6061-70ce-fb89-543829daaa9d/journal?type=TRADE&limit=10
Authorization: Bearer eyJhbGciOiJSUzI1NiIs...
```

**Response (200 OK):**
```json
{
  "statusCode": 200,
  "data": {
    "entries": [
      {
        "userId": "1448a458-6061-70ce-fb89-543829daaa9d",
        "entryId": "2025-09-04T03:15:23.456Z",
        "type": "TRADE",
        "title": "Successful ES breakout trade",
        "content": "Spotted clear breakout above 4520 resistance with strong volume...",
        "tags": ["breakout", "ES", "profitable"],
        "createdAt": "2025-09-04T03:15:23.456Z",
        "updatedAt": "2025-09-04T03:15:23.456Z"
      }
    ],
    "lastEvaluatedKey": "2025-09-04T03:15:23.456Z"
  }
}
```

---

#### POST `/api/users/{userId}/journal`
**Description**: Create a new journal entry  
**Method**: `POST`  
**Authentication**: Required (Cognito JWT)  
**Lambda Function**: `pfmon-test-journal-api`

**Request:**
```bash
POST /api/users/1448a458-6061-70ce-fb89-543829daaa9d/journal
Authorization: Bearer eyJhbGciOiJSUzI1NiIs...
Content-Type: application/json

{
  "type": "TRADE",
  "title": "Test Trade Entry",
  "content": "This is a test trade entry to verify API functionality.",
  "tags": ["test", "api-test", "trade"]
}
```

**Response (201 Created):**
```json
{
  "statusCode": 201,
  "message": "Journal entry created successfully", 
  "data": {
    "userId": "1448a458-6061-70ce-fb89-543829daaa9d",
    "entryId": "2025-09-04T03:20:15.789Z",
    "type": "TRADE",
    "title": "Test Trade Entry",
    "content": "This is a test trade entry to verify API functionality.",
    "tags": ["test", "api-test", "trade"],
    "createdAt": "2025-09-04T03:20:15.789Z",
    "updatedAt": "2025-09-04T03:20:15.789Z"
  }
}
```

---

#### PUT `/api/users/{userId}/journal`
**Description**: Update an existing journal entry  
**Method**: `PUT`  
**Authentication**: Required (Cognito JWT)  
**Lambda Function**: `pfmon-test-journal-api`

**Request:**
```bash
PUT /api/users/1448a458-6061-70ce-fb89-543829daaa9d/journal
Authorization: Bearer eyJhbGciOiJSUzI1NiIs...
Content-Type: application/json

{
  "entryId": "2025-09-04T03:20:15.789Z",
  "type": "TRADE", 
  "title": "Updated Test Trade Entry",
  "content": "Updated content for the test trade entry.",
  "tags": ["test", "api-test", "trade", "updated"]
}
```

**Response (200 OK):**
```json
{
  "statusCode": 200,
  "message": "Journal entry updated successfully",
  "data": {
    "userId": "1448a458-6061-70ce-fb89-543829daaa9d",
    "entryId": "2025-09-04T03:20:15.789Z",
    "type": "TRADE",
    "title": "Updated Test Trade Entry", 
    "content": "Updated content for the test trade entry.",
    "tags": ["test", "api-test", "trade", "updated"],
    "createdAt": "2025-09-04T03:20:15.789Z",
    "updatedAt": "2025-09-04T03:25:30.123Z"
  }
}
```

---

#### DELETE `/api/users/{userId}/journal`
**Description**: Delete a journal entry  
**Method**: `DELETE`  
**Authentication**: Required (Cognito JWT)  
**Lambda Function**: `pfmon-test-journal-api`

**Request:**
```bash
DELETE /api/users/1448a458-6061-70ce-fb89-543829daaa9d/journal
Authorization: Bearer eyJhbGciOiJSUzI1NiIs...
Content-Type: application/json

{
  "entryId": "2025-09-04T03:20:15.789Z"
}
```

**Response (200 OK):**
```json
{
  "statusCode": 200,
  "message": "Journal entry deleted successfully"
}
```

---

#### OPTIONS `/api/users/{userId}/journal`
**Description**: CORS preflight request  
**Method**: `OPTIONS`  
**Authentication**: None  
**Integration**: Mock (API Gateway)  
**Status**: ✅ **FIXED - Working with React app**

**Response Headers:**
```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS
Access-Control-Allow-Headers: Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token
```

---

## 🔄 **Planned Endpoints (Phase 3)**

### **🔐 User Credentials Endpoints**

#### GET `/api/users/{userId}/credentials`
**Description**: Retrieve encrypted trading system credentials  
**Status**: 🔄 **PLANNED**  
**Authentication**: Required (Cognito JWT)  
**Lambda Function**: `pfmon-test-credentials-api` (to be created)

#### POST `/api/users/{userId}/credentials`
**Description**: Store new trading system credentials (KMS encrypted)  
**Status**: 🔄 **PLANNED**  
**Authentication**: Required (Cognito JWT)  
**Lambda Function**: `pfmon-test-credentials-api` (to be created)

#### PUT `/api/users/{userId}/credentials`
**Description**: Update trading system credentials  
**Status**: 🔄 **PLANNED**  
**Authentication**: Required (Cognito JWT)

#### DELETE `/api/users/{userId}/credentials`
**Description**: Delete trading system credentials  
**Status**: 🔄 **PLANNED**  
**Authentication**: Required (Cognito JWT)

---

### **📊 Account Data Endpoints**

#### GET `/api/users/{userId}/accounts`
**Description**: Retrieve user's trading account information  
**Status**: 🔄 **PLANNED**  
**Authentication**: Required (Cognito JWT)  
**Lambda Function**: `pfmon-test-accounts-api` (to be created)

#### POST `/api/users/{userId}/accounts`
**Description**: Add new trading account  
**Status**: 🔄 **PLANNED**  
**Authentication**: Required (Cognito JWT)

#### PUT `/api/users/{userId}/accounts`
**Description**: Update account information  
**Status**: 🔄 **PLANNED**  
**Authentication**: Required (Cognito JWT)

#### DELETE `/api/users/{userId}/accounts`
**Description**: Remove trading account  
**Status**: 🔄 **PLANNED**  
**Authentication**: Required (Cognito JWT)

---

## 🛠️ **Technical Implementation Details**

### **Lambda Functions**
All Lambda functions use:
- **Runtime**: Node.js 20.x
- **Layer**: `pfmon-jwt-layer:1` (JWT validation)
- **DynamoDB**: Document Client (no manual marshalling)
- **Timeout**: 30 seconds
- **Memory**: 128 MB

### **DynamoDB Tables**
- **UserProfiles**: `pfmon-test-UserProfiles`
- **JournalEntries**: `pfmon-test-JournalEntries`
- **UserCredentials**: `pfmon-test-UserCredentials` (ready, no API yet)
- **AccountData**: `pfmon-test-AccountData` (ready, no API yet)

### **API Gateway Configuration**
- **API ID**: `g1zeanpn1a`
- **Stage**: `prod`
- **Authorizer**: Cognito User Pool (`pfmon-cognito-authorizer`)
- **CORS**: Fully configured for all methods
- **Integration**: AWS_PROXY with 29-second timeout

---

## 🧪 **Testing**

### **React Integration**
- ✅ **JournalApiTest.jsx**: Working test component
- ✅ **ApiService.js**: Automatic JWT token handling
- ✅ **useApi.js**: React hooks for API operations

### **Manual Testing**
```bash
# Test authentication (should return 401)
curl -X GET "https://g1zeanpn1a.execute-api.us-east-1.amazonaws.com/prod/api/users/test/profile"

# Test CORS preflight
curl -X OPTIONS "https://g1zeanpn1a.execute-api.us-east-1.amazonaws.com/prod/api/users/test/journal" \
  -H "Origin: http://localhost:3000" \
  -H "Access-Control-Request-Method: GET"
```

---

## 🚨 **Error Responses**

### **401 Unauthorized**
```json
{
  "message": "Unauthorized"
}
```

### **403 Forbidden** 
```json
{
  "statusCode": 403,
  "message": "Access denied"
}
```

### **404 Not Found**
```json
{
  "statusCode": 404, 
  "message": "Resource not found"
}
```

### **500 Internal Server Error**
```json
{
  "statusCode": 500,
  "message": "Internal server error"
}
```

---

## 📈 **Status Summary**

### **✅ Functional Endpoints (Phase 2 Complete)**
- User Profile: GET, PUT, OPTIONS
- Journal Entries: GET, POST, PUT, DELETE, OPTIONS
- CORS: Fully configured and working
- Authentication: JWT validation working
- Testing: React integration confirmed

### **🔄 Pending Endpoints (Phase 3)**
- User Credentials: All CRUD operations  
- Account Data: All CRUD operations
- WebSocket API: Real-time trading data (Phase 4)

**Total Progress**: **6/10 planned endpoints** (60% complete)