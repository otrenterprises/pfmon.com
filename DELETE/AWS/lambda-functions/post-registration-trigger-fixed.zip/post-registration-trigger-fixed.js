/**
 * Cognito Post-Registration Trigger Lambda Function - FIXED VERSION
 * 
 * This function is automatically triggered when a new user completes registration
 * in the Cognito User Pool. It creates a default UserProfiles entry in DynamoDB.
 * 
 * FIXES:
 * - Removed JWT dependencies (not needed for Cognito trigger)
 * - Fixed DynamoDB attribute structure
 * - Simplified nested objects to prevent marshalling errors
 */

const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { PutItemCommand } = require('@aws-sdk/client-dynamodb');

const dynamoClient = new DynamoDBClient({ region: process.env.REGION });

exports.handler = async (event, context) => {
    console.log('Post-Registration trigger received:', JSON.stringify(event, null, 2));
    
    try {
        // Extract user information from Cognito event
        const userId = event.request.userAttributes.sub; // Cognito user ID
        const email = event.request.userAttributes.email;
        const emailVerified = event.request.userAttributes.email_verified === 'true';
        
        console.log(`Creating profile for user: ${userId} (${email})`);
        
        // Create simple user profile entry - FIXED STRUCTURE
        const userProfile = {
            userId: { S: userId },
            dataType: { S: 'profile' },
            email: { S: email },
            emailVerified: { BOOL: emailVerified },
            createdAt: { S: new Date().toISOString() },
            lastUpdated: { S: new Date().toISOString() },
            
            // Simple preferences - no deep nesting
            theme: { S: 'dark' },
            timezone: { S: 'America/New_York' },
            defaultCurrency: { S: 'USD' },
            
            // User status and metadata
            status: { S: 'active' },
            registrationSource: { S: 'web' },
            userPoolId: { S: event.userPoolId },
            cognitoUsername: { S: event.userName }
        };
        
        // Insert into UserProfiles table
        const putCommand = new PutItemCommand({
            TableName: process.env.USER_PROFILES_TABLE_NAME,
            Item: userProfile,
            ConditionExpression: 'attribute_not_exists(userId)', // Prevent duplicates
        });
        
        await dynamoClient.send(putCommand);
        
        console.log(`✅ Successfully created user profile for ${userId} (${email})`);
        
        // Create welcome journal entry - SIMPLIFIED STRUCTURE
        const welcomeEntry = {
            userId: { S: userId },
            entryId: { S: `${new Date().toISOString().split('T')[0]}#welcome` },
            type: { S: 'LESSON' },
            title: { S: 'Welcome to PFMON Trading Journal' },
            content: { S: 'Welcome to your professional trading journal! Start by connecting your trading accounts in the Settings page, then begin logging your trades and insights.' },
            createdAt: { S: new Date().toISOString() },
            lastUpdated: { S: new Date().toISOString() },
            isSystemGenerated: { BOOL: true }
        };
        
        const journalCommand = new PutItemCommand({
            TableName: process.env.JOURNAL_ENTRIES_TABLE_NAME,
            Item: welcomeEntry
        });
        
        await dynamoClient.send(journalCommand);
        
        console.log(`✅ Created welcome journal entry for ${userId}`);
        
        // Return the event unchanged (required by Cognito)
        return event;
        
    } catch (error) {
        console.error('❌ Post-registration trigger failed:', error);
        
        // Log detailed error information
        console.error('Error details:', {
            errorMessage: error.message,
            errorStack: error.stack,
            userId: event.request?.userAttributes?.sub,
            email: event.request?.userAttributes?.email
        });
        
        // IMPORTANT: Don't throw error - this would prevent user registration
        // Instead, log the error and continue with registration
        return event;
    }
};